package CreateOrder;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BaseTest.BaseTest;
import CommonActions.BusinessCommonActions;
import Pages.CreateOrderPage;
import Pages.RegisterPage;

public class TC02_SelectSubCategory extends BaseTest{

	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		registerPage = new RegisterPage(driver);
		createOrderPage = new CreateOrderPage(driver);

	}
	@Test(description = "TC01_RigesterToTheWebsite")
	public void RigesterToTheWebsite() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Actions action = new Actions(driver);
		action.moveToElement(createOrderPage.Category).perform();
		createOrderPage.SelectSubCategory();



	
}}
