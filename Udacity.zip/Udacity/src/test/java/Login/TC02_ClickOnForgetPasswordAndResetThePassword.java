package Login;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BaseTest.BaseTest;
import CommonActions.BusinessCommonActions;
import Pages.LoginPage;

public class TC02_ClickOnForgetPasswordAndResetThePassword extends BaseTest {

	
	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		loginPage = new LoginPage(driver);
	}
	@Test(description = "TC01_LoginWithValidCredentials")
	public void LoginWithValidCredentials() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		loginPage.clickOnLoginBtn();
		loginPage.ClickOnForgetPasswordAndResetThePassword();


	
	
}}
