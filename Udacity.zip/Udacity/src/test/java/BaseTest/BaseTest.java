package BaseTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import CommonActions.BusinessCommonActions;
import Pages.BasePage;
import Pages.CreateOrderPage;
import Pages.LoginPage;
import Pages.RegisterPage;

public class BaseTest {
	public WebDriver driver;
	public BusinessCommonActions businessCommonActions;
	public BasePage basePage;
	protected RegisterPage registerPage;
	protected LoginPage loginPage;
	public CreateOrderPage createOrderPage;




	public BaseTest() {
		businessCommonActions = new BusinessCommonActions(driver);
	}




	@BeforeTest
	public void OpenwebDriver() throws InterruptedException  
	{
		String chromePath = System.getProperty("user.dir")+ "\\Sources\\chromedriver.exe" ;
		System.setProperty("webdriver.chrome.driver",chromePath);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://demo.nopcommerce.com/");


	}


	@AfterTest
	public void QUitDriver() throws InterruptedException  {

		driver.close();



	}





}
