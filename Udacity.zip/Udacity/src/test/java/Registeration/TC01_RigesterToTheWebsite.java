package Registeration;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BaseTest.BaseTest;
import CommonActions.BusinessCommonActions;
import Pages.RegisterPage;

public class TC01_RigesterToTheWebsite extends BaseTest {

	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		registerPage = new RegisterPage(driver);
	}
	@Test(description = "TC01_RigesterToTheWebsite")
	public void RigesterToTheWebsite() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		registerPage.clickOnRegisterBtn();
		registerPage.EnterThePersonalDetails();



	}

}







