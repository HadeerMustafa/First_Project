package Registeration;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import BaseTest.BaseTest;
import CommonActions.BusinessCommonActions;
import Pages.RegisterPage;

public class TC02_RigesterToTheWebsite extends BaseTest{
	
	@BeforeMethod
	public void intalizer() {
		businessCommonActions = new BusinessCommonActions(driver);
		registerPage = new RegisterPage(driver);
	}
	@Test(description = "TC02_RigesterToTheWebsite")
	public void RigesterToTheWebsite() throws InterruptedException {

		Thread.sleep(2000);



	}
	
}
