package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;



public class BasePage {

	public WebDriver driver;
	public WebDriverWait wait;
	public WebDriverWait WaitElmt;
	public ScrollingActions scrollingActions;
	public BusinessCommonActions businessCommonActions;




	public BasePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver ,this);
//		wait = new WebDriverWait(driver, 20);
//		WaitElmt = new WebDriverWait(driver, 1);
	}

	

}
