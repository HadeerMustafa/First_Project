package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import CommonActions.BusinessCommonActions;
import CommonActions.ScrollingActions;

public class CreateOrderPage extends BasePage{

	WebDriver driver;

	public CreateOrderPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		businessCommonActions = new BusinessCommonActions(driver);
		scrollingActions = new ScrollingActions(driver);
	}


	@FindBy(id = "small-searchterms")
	public WebElement SearchBar;

	@FindBy(css = "#small-search-box-form >button")
	public WebElement SearchButton;

	@FindBy(className = "product-title")
	public WebElement product_Title;

	@FindBy(xpath = "/html/body/div[6]/div[2]/ul[1]/li[3]/a")
	public WebElement Category;

	@FindBy(xpath = "/html/body/div[6]/div[2]/ul[1]/li[3]/ul/li[1]/a")
	public WebElement SubCategory;

	@FindBy(className = "page-title")
	public WebElement page_Title;

	@FindBy(className = "add-to-wishlist-button")
	public WebElement WishListBtn;

	@FindBy(className = "add-to-compare-list-button")
	public WebElement CompareListBtn;

	@FindBy(id = "bar-notification")
	public WebElement NotificationMsg;

	@FindBy(className = "product-name")
	public WebElement ProductName;

	@FindBy(id = "product_attribute_2")
	public WebElement RAM_list;

	@FindBy(id = "product_attribute_3_6")
	public WebElement HDD_Option;

	@FindBy(id = "customerCurrency")
	public WebElement customerCurrency;

	@FindBy(className = "product-box-add-to-cart-button")
	public WebElement AddToCartBtn;

	@FindBy(id = "add-to-cart-button-1")
	public WebElement AddProductToCart;

	@FindBy(id = "topcartlink")
	public WebElement ShoppingCart;

	@FindBy(id = "checkout")
	public WebElement checkout;

	@FindBy(id = "termsofservice")
	public WebElement termsofservice;

	@FindBy(name = "save")
	public WebElement saveBtn;

	@FindBy(id = "BillingNewAddress_City")
	public WebElement BillingNewAddress_City;

	@FindBy(id = "BillingNewAddress_CountryId")
	public WebElement BillingNewAddress_CountryId;

	@FindBy(id = "BillingNewAddress_Address1")
	public WebElement BillingNewAddress_Address1;

	@FindBy(xpath = "//*[@id=\"BillingNewAddress_Address2\"]")
	public WebElement BillingNewAddress_Address2;

	@FindBy(id = "BillingNewAddress_ZipPostalCode")
	public WebElement BillingNewAddress_ZipPostalCode;

	@FindBy(id = "BillingNewAddress_PhoneNumber")
	public WebElement BillingNewAddress_PhoneNumber;

	@FindBy(xpath = "//*[@id=\"BillingNewAddress_FaxNumber\"]")
	public WebElement BillingNewAddress_FaxNumber;

	@FindBy(xpath = "//*[@id=\"shipping-method-buttons-container\"]/button")
	public WebElement shipping_method_next_step_button;

	@FindBy(id = "shipping-methods-form")
	public WebElement shipping_methods_form;

	@FindBy(id = "payment-method-block")
	public WebElement payment_method_block;

	@FindBy(xpath = "//*[@id=\"payment-method-buttons-container\"]/button")
	public WebElement payment_method_next_step_button;

	@FindBy(xpath = "//*[@id=\"payment-info-buttons-container\"]/button")
	public WebElement payment_info_next_step_button;

	@FindBy(id = "shopping-cart-form")
	public WebElement shopping_cart_form;

	@FindBy(xpath = "//*[@id=\"confirm-order-buttons-container\"]/button")
	public WebElement confirm_order_next_step_button;

	@FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div/div[1]/strong")
	public WebElement confirm_order_Msg;
	
	@FindBy(className = "close")
	public WebElement closeBtn;
	
	
	
	


	@Step("Search on product")
	public void SearchOnProduct() throws InterruptedException {

		businessCommonActions.EnterText(SearchBar,"Computer");	
		businessCommonActions.ClickOnWebElement(SearchButton);
		Thread.sleep(2000);
		scrollingActions.SwipScreenDownToWebElement(product_Title);
		Assert.assertEquals("Build your own computer", businessCommonActions.getText(product_Title));

	} 

	@Step("Select Sub Category")
	public void SelectSubCategory() throws InterruptedException {

		//		Actions action = new Actions(driver);
		//		action.moveToElement(Category).perform();
		businessCommonActions.ClickOnWebElement(SubCategory);
		Thread.sleep(2000);
		Assert.assertEquals("Shoes", businessCommonActions.getText(page_Title));

	}

	@Step("Open Product Details")
	public void OpenProductDetails() throws InterruptedException {

		Thread.sleep(2000);
		scrollingActions.SwipScreenDownToWebElement(WishListBtn);
		businessCommonActions.ClickOnWebElement(AddToCartBtn);
		Assert.assertEquals("Build your own computer", businessCommonActions.getText(product_Title));
		scrollingActions.SwipScreenDownToWebElement(HDD_Option);
		Select RAM = new Select(RAM_list);
		RAM.selectByVisibleText("2 GB");
		RAM.selectByIndex(1);
		businessCommonActions.ClickOnWebElement(HDD_Option);

	} 

	@Step("Add product to wish list")
	public void AddProductToWishList() throws InterruptedException {

		businessCommonActions.ClickOnWebElement(WishListBtn);
		Thread.sleep(2000);
		Assert.assertEquals("The product has been added to your wishlist", businessCommonActions.getText(NotificationMsg));

	} 

	@Step("Add product to comare list")
	public void AddProductToCompareList() throws InterruptedException {
		Thread.sleep(2000);
		scrollingActions.SwipScreenDownToWebElement(WishListBtn);
		businessCommonActions.ClickOnWebElement(CompareListBtn);
		Thread.sleep(2000);
		Assert.assertEquals("The product has been added to your product comparison", businessCommonActions.getText(NotificationMsg));



	} 

	@Step("Select Diffrent currencies")
	public void SelectDiffrentcurrencies () throws InterruptedException {

		Thread.sleep(2000);
		scrollingActions.SwipScreenDownToWebElement(WishListBtn);
		businessCommonActions.ClickOnWebElement(WishListBtn);
		Select currencies = new Select(RAM_list);
		currencies.selectByIndex(2);


	} 

	@Step("Add Product To Cart")
	public void AddProductToCart () throws InterruptedException {

		businessCommonActions.ClickOnWebElement(AddProductToCart);
		Thread.sleep(2000);
		Assert.assertEquals("The product has been added to your shopping cart", businessCommonActions.getText(NotificationMsg));	
		businessCommonActions.ClickOnWebElement(closeBtn);


	} 

	@Step("Open Shopping cart")
	public void OpenSHoppingCart () throws InterruptedException {

		businessCommonActions.ClickOnWebElement(ShoppingCart);
		Thread.sleep(2000);
		Assert.assertEquals("Shopping cart", businessCommonActions.getText(page_Title));


	} 

	@Step("Proceed To CheckOut")
	public void ProceedToCheckOut () throws InterruptedException {

		scrollingActions.SwipScreenDownToWebElement(checkout);
		businessCommonActions.ClickOnWebElement(termsofservice);
		businessCommonActions.ClickOnWebElement(checkout);
		Thread.sleep(2000);
		Assert.assertEquals("Checkout", businessCommonActions.getText(page_Title));

	}


	@Step("Billing Address Form")
	public void BillingAddressForm () {

		scrollingActions.ElementIsVisableForScroll(BillingNewAddress_CountryId);
		Select country = new Select(BillingNewAddress_CountryId);
		country.selectByVisibleText("Albania");
		country.selectByIndex(3);
		scrollingActions.ElementIsVisableForScroll(BillingNewAddress_City);
		businessCommonActions.EnterText(BillingNewAddress_City,"Cairo");
		businessCommonActions.EnterText(BillingNewAddress_Address1,"Address 1");
		businessCommonActions.EnterText(BillingNewAddress_Address2,"Address 2");
		businessCommonActions.EnterText(BillingNewAddress_ZipPostalCode,"1234");
		businessCommonActions.EnterText(BillingNewAddress_PhoneNumber,"01111111111");
		businessCommonActions.EnterText(BillingNewAddress_FaxNumber,"12345");
		businessCommonActions.ClickOnWebElement(saveBtn);

		businessCommonActions.checkIfElementISDisplayed(shipping_methods_form);

	}


	@Step("Shipping Address Form")
	public void ShippingAddressForm (){

		businessCommonActions.ClickOnWebElement(shipping_method_next_step_button);
		businessCommonActions.checkIfElementISDisplayed(payment_method_block);
	}


	@Step("Select Payment Options")
	public void SelectPaymentOptions () {

		businessCommonActions.ClickOnWebElement(payment_method_next_step_button);
		businessCommonActions.checkIfElementISDisplayed(payment_info_next_step_button);
		businessCommonActions.ClickOnWebElement(payment_info_next_step_button);

	}

	@Step("Conirm Order")
	public void ConirmOrder () {

		scrollingActions.SwipScreenDownToWebElement(confirm_order_next_step_button);
		businessCommonActions.checkIfElementISDisplayed(shopping_cart_form);
		businessCommonActions.ClickOnWebElement(confirm_order_next_step_button);	
		Assert.assertEquals("Your order has been successfully processed!", businessCommonActions.getText(confirm_order_Msg));

	}





}
