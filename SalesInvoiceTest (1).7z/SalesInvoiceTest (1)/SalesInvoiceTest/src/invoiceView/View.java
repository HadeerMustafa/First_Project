
package invoiceView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTable;

import invoiceModel.HeaderModel;
import invoiceModel.HeaderTable;
import invoiceModel.ItemModel;
import project.controller.Controller;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.SystemColor;

//this page to create Frame UI and buttons and inherite from controller the actions
public class View extends javax.swing.JFrame {

    public View() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
   
    private void initComponents() {

    	ScrollPanelOne = new javax.swing.JScrollPane();
        invoicesTable = new javax.swing.JTable();
        invoicesTable.getSelectionModel().addListSelectionListener(listener);
        Label1 = new javax.swing.JLabel();
        Label1.setFont(new Font("Tahoma", Font.BOLD, 11));
        Label2 = new javax.swing.JLabel();
        Label2.setFont(new Font("Tahoma", Font.BOLD, 11));
        Label3 = new javax.swing.JLabel();
        Label3.setFont(new Font("Tahoma", Font.BOLD, 11));
        Label4 = new javax.swing.JLabel();
        Label4.setFont(new Font("Tahoma", Font.BOLD, 11));
        customerNameLbl = new javax.swing.JLabel();
        invNumLbl = new javax.swing.JLabel();
        invDateLbl = new javax.swing.JLabel();
        invTotalLbl = new javax.swing.JLabel();
        ScrollPanelTwo = new javax.swing.JScrollPane();
        linesTable = new javax.swing.JTable();
        ButtonOne = new javax.swing.JButton();
        ButtonOne.setFont(new Font("Tahoma", Font.PLAIN, 11));
        ButtonOne.addActionListener(listener);
        ButtonTwo = new javax.swing.JButton();
        ButtonTwo.addActionListener(listener);
        ButtonThree = new javax.swing.JButton();
        ButtonThree.addActionListener(listener);
        ButtonFour = new javax.swing.JButton();
        ButtonFour.addActionListener(listener);
        MenuBar1 = new javax.swing.JMenuBar();
        Menu1 = new javax.swing.JMenu();
        MenuItem1 = new javax.swing.JMenuItem();
        MenuItem1.setBackground(SystemColor.activeCaption);
        MenuItem1.addActionListener(listener);
        MenuItem2 = new javax.swing.JMenuItem();
        MenuItem2.setBackground(SystemColor.activeCaption);
        MenuItem2.addActionListener(listener);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        invoicesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ScrollPanelOne.setViewportView(invoicesTable);
//create and set lables name
        Label1.setText("Invoice Num");

        Label2.setText("Customer Name");

        Label3.setText("Invoice Date");

        Label4.setText("Invoice Total");

        customerNameLbl.setText(".");

        invNumLbl.setText(".");

        invDateLbl.setText(".");

        invTotalLbl.setText(".");

        linesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        ScrollPanelTwo.setViewportView(linesTable);
//buttons
        ButtonOne.setText("Create New Invoice");

        ButtonTwo.setText("Delete selected Invoice");

        ButtonThree.setText("New Invoice Line");

        ButtonFour.setText("Delete Invoice Line");
//menu items
        Menu1.setText("File");

        MenuItem1.setText("Load");
        Menu1.add(MenuItem1);

        MenuItem2.setText("Save");
        Menu1.add(MenuItem2);

        MenuBar1.add(Menu1);

        setJMenuBar(MenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(ButtonOne)
                .addGap(106, 106, 106)
                .addComponent(ButtonTwo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 124, Short.MAX_VALUE)
                .addComponent(ButtonThree)
                .addGap(85, 85, 85)
                .addComponent(ButtonFour)
                .addGap(91, 91, 91))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ScrollPanelOne, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Label2)
                            .addComponent(Label1)
                            .addComponent(Label3)
                            .addComponent(Label4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(invTotalLbl)
                            .addComponent(invDateLbl)
                            .addComponent(invNumLbl)
                            .addComponent(customerNameLbl))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(ScrollPanelTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Label1)
                            .addComponent(invNumLbl))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Label2)
                            .addComponent(customerNameLbl))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Label3)
                            .addComponent(invDateLbl))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Label4)
                            .addComponent(invTotalLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ScrollPanelTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ScrollPanelOne, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonOne)
                    .addComponent(ButtonTwo)
                    .addComponent(ButtonThree)
                    .addComponent(ButtonFour))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                View f = new View();
                f.listener.load("InvoiceHeader.csv", "InvoiceLine.csv");
                f.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel customerNameLbl;
    private javax.swing.JLabel invDateLbl;
    private javax.swing.JLabel invNumLbl;
    private javax.swing.JLabel invTotalLbl;
    private javax.swing.JTable invoicesTable;
    private javax.swing.JButton ButtonOne;
    private javax.swing.JButton ButtonTwo;
    private javax.swing.JButton ButtonThree;
    private javax.swing.JButton ButtonFour;
    private javax.swing.JLabel  Label1;
    private javax.swing.JLabel  Label2;
    private javax.swing.JLabel  Label3;
    private javax.swing.JLabel  Label4;
    private javax.swing.JMenu Menu1;
    private javax.swing.JMenuBar MenuBar1;
    private javax.swing.JMenuItem  MenuItem1;
    private javax.swing.JMenuItem MenuItem2;
    private javax.swing.JScrollPane ScrollPanelOne;
    private javax.swing.JScrollPane ScrollPanelTwo;
    private javax.swing.JTable linesTable;
    // End of variables declaration//GEN-END:variables
    private Controller listener = new Controller(this);
    //changing date formate
    public static DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
    private ArrayList<HeaderTable> invoices;
    private HeaderModel headerTableModeOne;
    private ItemModel itemTableModel;

    public int getNextInvNum() {
        int num = 0;
        for (HeaderTable invoice : getInvoices()) {
            if (invoice.getNum() > num) num = invoice.getNum();
        }
        return num + 1;
    }
    
    public ItemModel getItemTableModel() {
        return itemTableModel;
    }

    public void setItemTableModel(ItemModel itemTableModel) {
        this.itemTableModel = itemTableModel;
        linesTable.setModel(itemTableModel);
    }

    public ArrayList<HeaderTable> getInvoices() {
        if (invoices == null)
            invoices = new ArrayList<>();
        return invoices;
    }

    public HeaderTable getInvoiceByNum(int num) {
    	HeaderTable inv = null;
        for (HeaderTable item : getInvoices()) {
            if (item.getNum() == num) {
                inv = item;
                break;
            }
        }
        return inv;
    }
    
    public HeaderTable getInvoiceByNum2(int num) {
        for (HeaderTable item : getInvoices()) {
            if (item.getNum() == num) {
                return item;
            }
        }
        return null;
    }
    
    public void setHeaderTableModel(HeaderModel headerTableModel) {
        this.headerTableModeOne = headerTableModel;
        this.invoicesTable.setModel(headerTableModel);
    }

    public HeaderModel getHeaderTableModel() {
        return headerTableModeOne;
    }

    public JLabel getCustomerNameLbl() {
        return customerNameLbl;
    }

    public JLabel getInvDateLbl() {
        return invDateLbl;
    }

    public JLabel getInvNumLbl() {
        return invNumLbl;
    }

    public JLabel getInvTotalLbl() {
        return invTotalLbl;
    }

    public JTable getInvoicesTable() {
        return invoicesTable;
    }

    public JTable getLinesTable() {
        return linesTable;
    }

    public Controller getListener() {
        return listener;
    }
    
    
    
    
}
