/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invoiceView;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import invoiceView.View;


public class InvoiceHeaderView extends JDialog {
	private JTextField custNameTextField;
	private JTextField invDateTextField;
	private JLabel custNameLbOne;
	private JLabel invDateLbOne;
	private JButton Ok_Btn;
	private JButton Cancel_Btn;

	public InvoiceHeaderView(View view) {
		custNameLbOne = new JLabel("Customer Name:");
		custNameTextField = new JTextField(20);
		invDateLbOne = new JLabel("Invoice Date:");
		invDateTextField = new JTextField(20);
		Ok_Btn = new JButton("OK");
		Cancel_Btn = new JButton("Cancel");

		Ok_Btn.setActionCommand("newInvoiceOK");
		Cancel_Btn.setActionCommand("newInvoiceCancel");

		Ok_Btn.addActionListener(view.getListener());
		Cancel_Btn.addActionListener(view.getListener());
		setLayout(new GridLayout(3, 2));

		add(invDateLbOne);
		add(invDateTextField);
		add(custNameLbOne);
		add(custNameTextField);
		add(Ok_Btn);
		add(Cancel_Btn);
		setModal(true);
		pack();

	}

	public JTextField getCustNameField() {
		return custNameTextField;
	}

	public JTextField getInvDateField() {
		return invDateTextField;
	}

}
