
package invoiceModel;
//model to create table Items

public class ItemTable {

	private String Name;
	private int Price;
	private int Count;
	private HeaderTable invoice;

	public ItemTable(String name, int price, int count, HeaderTable invoice) {
		this.Name = name;
		this.Price = price;
		this.Count = count;
		this.invoice = invoice;
		invoice.getItems().add(this);
	}

	public int getTotal() {
		return Price * Count;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		this.Price = price;
	}

	public int getCount() {
		return Count;
	}

	public void setCount(int count) {
		this.Count = count;
	}

	public HeaderTable getInvoice() {
		return invoice;
	}

	public void setInvoice(HeaderTable invoice) {
		this.invoice = invoice;
	}

	@Override
	public String toString() {
		return "InvoiceItem{" + "name=" + Name + ", price=" + Price + ", count=" + Count + '}';
	}

	public String getAsCSV() {
		return getInvoice().getNum()+","+getName()+","+Price+","+Count;
	}

}
