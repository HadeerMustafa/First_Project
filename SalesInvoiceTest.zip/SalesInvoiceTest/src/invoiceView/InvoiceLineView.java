
package invoiceView;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import invoiceView.View;


public class InvoiceLineView extends JDialog{
    private JTextField item_Name;
    private JTextField item_Count;
    private JTextField item_Price;
    private JLabel itemNameLb_l;
    private JLabel itemCountLb_l;
    private JLabel itemPriceLb_l;
    private JButton Ok_Btn;
    private JButton cancel_Btn;
    
    public InvoiceLineView(View view) {
    	item_Name = new JTextField(20);
    	itemNameLb_l = new JLabel("Item Name");
        
        item_Count = new JTextField(20);
        itemCountLb_l = new JLabel("Item Count");
        
        item_Price = new JTextField(20);
        itemPriceLb_l = new JLabel("Item Price");
        
        Ok_Btn = new JButton("OK");
        cancel_Btn = new JButton("Cancel");
        
        Ok_Btn.setActionCommand("newLineOK");
        cancel_Btn.setActionCommand("newLineCancel");
        
        Ok_Btn.addActionListener(view.getListener());
        cancel_Btn.addActionListener(view.getListener());
        setLayout(new GridLayout(6, 2));
        
        add(itemNameLb_l);
        add(item_Name);
        add(itemCountLb_l);
        add(item_Count);
        add(itemPriceLb_l);
        add(item_Price);
        add(Ok_Btn);
        add(cancel_Btn);
        setModal(true);
        pack();
    }

    public JTextField getItemNameField() {
        return item_Name;
    }

    public JTextField getItemCountField() {
        return item_Count;
    }

    public JTextField getItemPriceField() {
        return item_Price;
    }
}
